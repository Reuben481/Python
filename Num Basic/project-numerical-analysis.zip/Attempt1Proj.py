# -*- coding: utf-8 -*-
"""
Created on Wed May 18 16:00:03 2016

@author: reuben
"""
#Task 1(b-d)
from scipy import*
from scipy import interpolate
from pylab import *
from numpy import *
from matplotlib.pyplot import *
from mpl_toolkits.mplot3d import Axes3D
import sys

def f(a):
    beta=9.81
    return (-beta*sin(a))
#variables

ah=0.001
an=10000
aalpha=pi/2
aomega=0
at=0
def fu(h,alpha,omega,n,t):
    """Trapezoidal interpolation of second order differential equation.
    f = second derivative with respect to the original integral.(input=fn)
    Omega = first derivative in numerical basis.(input=init val)
    Alpha = function being interpolated.(input=init val)
    """
    v=array([alpha,omega,t])
    l=[]
    l1=[]
    l2=[]
    for i in range(1,n):
        k1a=h*omega
        k1b=h*f(alpha)
        k2a=h*(omega+k1b)
        k2b=h*f(alpha+k1a)
        alpha+=(k1a+k2a)/2
        omega+=(k1b+k2b)/2
        t+=h
        l.append(alpha)
        l1.append(omega)
        l2.append(t)
        v=vstack((v,(alpha,omega,t)))
        i+=1
    return v,l,l1,l2

print(fu(ah,aalpha,aomega,an,at)[0])
plot(fu(ah,aalpha,aomega,an,at)[1])
plot(fu(ah,aalpha,aomega,an,at)[2])
#hobs=0.1
#nobs=100
#alphaobs=pi/2
#omegaobs=0
#tobs=0
#print(fu(hobs,alphaobs,omegaobs,nobs,tobs)[0])
#plot(fu(hobs,alphaobs,omegaobs,nobs,tobs)[1])
#plot(fu(hobs,alphaobs,omegaobs,nobs,tobs)[2]) 

#Task 2        
def fub(a,b):
    """
    input: array of x values and y values of the function. Returns 
    as many nodes as there are values in the arrays.
    Array should be of the same dimensions, and always (1,n) in shape. 
    """
    
    l=[]
    l1=[]
    l2=[]
    l3=[]
    for i in a:
        l.append(np.poly1d([1,-i]))
    for h in l:
        product=1   
        for z in l:
            if h!=z:
                product*=z
        l1.append(product)
    for i in a:
        r=1
        for h in l:
            if h(i)!=0:
                r*=h(i)
        l2.append(r)
    u,=a.shape
    for i in range (u):
        l3.append(l1[i]/l2[i])
    lgp=0
    for i in range (u):
        lgp+=l3[i]*b[i]
    return lgp    

r=array(fu(ah,aalpha,aomega,an,at)[3])#t
a=array(fu(ah,aalpha,aomega,an,at)[2])#omega
b=array(fu(ah,aalpha,aomega,an,at)[1])#alpha

z=[fub(a[0:3],r[0:3])]
#for i in range(1,len(a)-2):
#    fi=fub(a[i:i+3],r[i:i+3])
#    z.append(fi)
#
#y=[fub(a[0:3],b[0:3])]
#for i in range(1,len(a)-2):
#    fi=fub(a[i:i+3],r[i:i+3])
#    y.append(fi)

def fuba(x,y):
    alphaobs=2*pi/3
    for i in range(1,len(a)-2):
        t=x[i]
        fi=fub(x[i:i+3],y[i:i+3])
        if abs(fi(t)-alphaobs)<=1.e-2:

            return abs(fub(x[i:i+3],y[i:i+3])(t)-alphaobs),i
    

print(fuba(r,a))
print(2*pi/3)
#print(fuba(b,r))

    


        
        
        

        
